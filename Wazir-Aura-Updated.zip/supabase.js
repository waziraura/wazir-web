const SUPABASE_URL = "https://qswvuitxfamztcofauib.supabase.co";
const SUPABASE_PUBLISHABLE_KEY = "sb_publishable_YoNibTafnFTJXyQF-4hA4A_zktjPFh2";
const CONTACT_FUNCTION_URL = `${SUPABASE_URL}/functions/v1/submit-contact`;

export async function submitContactMessage(payload) {
  const name = String(payload?.name ?? "").trim();
  const email = String(payload?.email ?? "").trim();
  const subject = String(payload?.subject ?? "").trim();
  const message = String(payload?.message ?? "").trim();
  const turnstileToken = String(payload?.turnstileToken ?? "").trim();

  if (name.length < 2 || name.length > 100) {
    throw new Error("Please enter a name between 2 and 100 characters.");
  }
  if (email.length < 5 || email.length > 254 || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
    throw new Error("Please enter a valid email address.");
  }
  if (!subject || subject.length > 160) {
    throw new Error("Please enter a subject (up to 160 characters).");
  }
  if (message.length < 10 || message.length > 5000) {
    throw new Error("Your message must be between 10 and 5000 characters.");
  }
  if (!turnstileToken) {
    throw new Error("Please complete the security verification.");
  }

  let response;
  try {
    response = await fetch(CONTACT_FUNCTION_URL, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "apikey": SUPABASE_PUBLISHABLE_KEY,
        "Authorization": `Bearer ${SUPABASE_PUBLISHABLE_KEY}`
      },
      body: JSON.stringify({ name, email, subject, message, turnstileToken })
    });
  } catch (error) {
    throw new Error("Network error. Check your connection and try again.");
  }

  let result = {};
  const responseText = await response.text();
  if (responseText) {
    try { result = JSON.parse(responseText); }
    catch { result = { message: responseText }; }
  }

  if (!response.ok || result.success === false || result.error) {
    const messageFromServer = result.message || result.error;
    if (response.status === 429) {
      throw new Error("Too many requests. Please wait a little and try again.");
    }
    throw new Error(
      typeof messageFromServer === "string"
        ? messageFromServer
        : "Your message could not be sent. Please try again later."
    );
  }

  return result;
}
