WAZIR AURA UPDATE

Files: index.html, style.css, script.js, supabase.js, favicon.svg

Implemented in this update:
- MW monogram treatment and animated gradient half-circle/flame effect
- Custom MW SVG favicon
- Intro screen has an independent 3-second fallback, plus Enter/Skip controls
- Updated Proton email, LinkedIn, Instagram, Fiverr links; removed old email and any YouTube/Twitter links
- Expanded Murad Wazir About copy
- Free browser tools: notepad with local save, TXT download, word/character count, case converter, JSON formatter/minifier, Base64 encode/decode, password generator, device/browser text-to-speech voices, structured prompt builder
- Inputs accept up to 100,000 characters where supported by browser performance
- Contact form has a mailto fallback if Turnstile is unavailable

Important integration notes:
- Real AI image/video generation, AI Q&A/study help, code generation, and live website/game generation require an AI provider API and secure backend. Do not put private API keys in frontend files.
- Speech voices are supplied by the user's browser/operating system; the website does not bundle 100+ voices.
- Paid plans, payment processing, ad monetization, accounts and premium entitlements require backend/payment/ad-provider setup. No fake checkout is included.
- Contact form delivery still depends on the configured Supabase backend and its server-side verification settings. If Turnstile is unavailable in the browser, the page opens the user's email app instead.
- Deploy all files together in the same directory. Ensure filename casing matches exactly.
