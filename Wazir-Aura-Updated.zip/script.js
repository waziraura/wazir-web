import * as THREE from "three";
import { submitContactMessage } from "./supabase.js";

const $ = (selector, root = document) => root.querySelector(selector);
const $$ = (selector, root = document) => [...root.querySelectorAll(selector)];

const welcomeScreen = $("#welcomeScreen");
const enterButton = $("#welcomeEnter");
const skipButton = $("#welcomeSkip");

function closeIntro() {
  if (!welcomeScreen || welcomeScreen.classList.contains("is-leaving")) return;
  welcomeScreen.classList.add("is-leaving");
  document.body.classList.add("intro-complete");
  window.setTimeout(() => welcomeScreen.remove(), 900);
}
enterButton?.addEventListener("click", closeIntro);
skipButton?.addEventListener("click", closeIntro);
window.setTimeout(() => {
  if (welcomeScreen && !welcomeScreen.classList.contains("is-leaving")) closeIntro();
}, 3000);

// Footer year
const year = $("#year");
if (year) year.textContent = String(new Date().getFullYear());

// Mobile navigation
const menuToggle = $("#menuToggle");
const mainNav = $("#mainNav");
function closeMenu() {
  mainNav?.classList.remove("is-open");
  menuToggle?.setAttribute("aria-expanded", "false");
  menuToggle?.setAttribute("aria-label", "Open navigation");
}
menuToggle?.addEventListener("click", () => {
  const open = mainNav?.classList.toggle("is-open") ?? false;
  menuToggle.setAttribute("aria-expanded", String(open));
  menuToggle.setAttribute("aria-label", open ? "Close navigation" : "Open navigation");
});
$$(".main-nav a").forEach(link => link.addEventListener("click", closeMenu));
window.addEventListener("resize", () => {
  if (window.innerWidth > 720) closeMenu();
});

// Theme toggle
const themeToggle = $("#themeToggle");
const themeLabel = $("#themeLabel");
themeToggle?.addEventListener("click", () => {
  const garden = document.body.classList.toggle("theme-garden");
  if (themeLabel) themeLabel.textContent = garden ? "Garden mode" : "Space mode";
  themeToggle.setAttribute("aria-label", garden ? "Switch to space theme" : "Switch to garden theme");
});

// Reveal-on-scroll, with fallback
const revealItems = $$(".reveal");
if ("IntersectionObserver" in window) {
  const revealObserver = new IntersectionObserver(entries => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.add("is-visible");
        revealObserver.unobserve(entry.target);
      }
    });
  }, { threshold: 0.12 });
  revealItems.forEach(item => revealObserver.observe(item));
} else {
  revealItems.forEach(item => item.classList.add("is-visible"));
}

// Toast
let toastTimer;
function showToast(message) {
  const toast = $("#toast");
  if (!toast) return;
  toast.textContent = message;
  toast.classList.add("show");
  window.clearTimeout(toastTimer);
  toastTimer = window.setTimeout(() => toast.classList.remove("show"), 3500);
}

// Details dialog
const modalContent = {
  about: ["My approach", "<p>I start by understanding the goal, audience and requirements. Then I agree on the scope, timeline and deliverables before beginning the work.</p><p>Clear communication and careful implementation help keep each project focused.</p>"],
  frontend: ["Frontend & web development", "<p>Responsive layouts, interactive interfaces and polished web experiences built around the project brief.</p><p>Scope and technical requirements are confirmed before work begins.</p>"],
  research: ["Web research & lead generation", "<p>Organised online research, information gathering and lead lists prepared to the agreed criteria.</p>"],
  data: ["Data entry & formatting", "<p>Structured data entry, spreadsheet updates, cleanup and formatting with attention to accuracy.</p>"],
  design: ["Social media banner design", "<p>Promotional banners and social graphics tailored to your platform, content and visual direction.</p>"],
  office: ["Office documents", "<p>Typing, Word document formatting, Excel data organisation and PowerPoint presentation support.</p>"],
  games: ["2D game development", "<p>Small 2D interactive concepts and learning-focused game projects. Feasibility is discussed before work begins.</p>"],
  lab: ["Inside the digital lab", "<p>The lab is where I explore interface design, motion, frontend techniques and small interactive experiments.</p>"],
  "project-space": ["Beyond the Orbit", "<p>A concept for a cinematic, space-inspired interface using depth, atmospheric lighting and motion.</p><p>This card describes a concept direction, not a claim of a completed client project.</p>"],
  "project-garden": ["Quiet Digital Garden", "<p>A calmer visual direction inspired by natural colours, soft shapes and a slower browsing rhythm.</p><p>This card describes a concept direction, not a claim of a completed client project.</p>"]
};
const dialog = $("#detailDialog");
const dialogTitle = $("#dialogTitle");
const dialogBody = $("#dialogBody");
$$("[data-modal]").forEach(button => {
  button.addEventListener("click", () => {
    const item = modalContent[button.dataset.modal];
    if (!item || !dialog || !dialogTitle || !dialogBody) return;
    dialogTitle.textContent = item[0];
    dialogBody.innerHTML = item[1];
    if (typeof dialog.showModal === "function") dialog.showModal();
    else showToast(item[0]);
  });
});
$("#dialogClose")?.addEventListener("click", () => dialog?.close());
dialog?.addEventListener("click", event => {
  if (event.target === dialog) dialog.close();
});
$("#dialogContact")?.addEventListener("click", () => dialog?.close());

// Three.js background scene. Falls back gracefully if WebGL/CDN is unavailable.
function initScene() {
  const canvas = $("#webgl-scene");
  if (!canvas) return;
  let renderer;
  try {
    renderer = new THREE.WebGLRenderer({ canvas, alpha: true, antialias: true });
  } catch (error) {
    console.warn("3D background unavailable; continuing without it.", error);
    return;
  }

  const scene = new THREE.Scene();
  const camera = new THREE.PerspectiveCamera(60, 1, 0.1, 100);
  camera.position.z = 12;
  const group = new THREE.Group();
  scene.add(group);

  const starCount = 650;
  const positions = new Float32Array(starCount * 3);
  for (let i = 0; i < starCount; i++) {
    positions[i * 3] = (Math.random() - 0.5) * 34;
    positions[i * 3 + 1] = (Math.random() - 0.5) * 22;
    positions[i * 3 + 2] = (Math.random() - 0.5) * 22;
  }
  const starGeometry = new THREE.BufferGeometry();
  starGeometry.setAttribute("position", new THREE.BufferAttribute(positions, 3));
  const stars = new THREE.Points(
    starGeometry,
    new THREE.PointsMaterial({ color: 0xbcb4ff, size: 0.035, transparent: true, opacity: 0.75 })
  );
  group.add(stars);

  const sphere = new THREE.Mesh(
    new THREE.SphereGeometry(2.5, 48, 48),
    new THREE.MeshBasicMaterial({ color: 0x5b4b9d, wireframe: true, transparent: true, opacity: 0.12 })
  );
  sphere.position.set(5.5, -1.8, -2);
  group.add(sphere);

  const reducedMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  let frame = 0;
  let running = false;
  const resize = () => {
    const width = window.innerWidth;
    const height = window.innerHeight;
    renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 1.6));
    renderer.setSize(width, height, false);
    camera.aspect = width / height;
    camera.updateProjectionMatrix();
  };
  const animate = () => {
    if (!running) return;
    frame = requestAnimationFrame(animate);
    if (!reducedMotion) {
      group.rotation.y += 0.00035;
      stars.rotation.z += 0.00008;
      sphere.rotation.y += 0.001;
    }
    renderer.render(scene, camera);
  };
  const start = () => {
    if (running) return;
    running = true;
    frame = requestAnimationFrame(animate);
  };
  const stop = () => {
    running = false;
    cancelAnimationFrame(frame);
  };
  resize();
  start();
  window.addEventListener("resize", resize);
  document.addEventListener("visibilitychange", () => {
    if (document.hidden) stop();
    else start();
  });
}
initScene();

// Cloudflare Turnstile
const SITE_KEY = "0x4AAAAAAFZJ224xUgfpye_d";
let turnstileWidgetId = null;
let turnstileToken = "";

function resetTurnstile() {
  turnstileToken = "";
  if (window.turnstile && turnstileWidgetId !== null) {
    try { window.turnstile.reset(turnstileWidgetId); } catch (error) {
      console.warn("Turnstile reset failed.", error);
    }
  }
}

function renderTurnstile() {
  const widget = $("#turnstileWidget");
  if (!widget || !window.turnstile || turnstileWidgetId !== null) return;
  const siteKey = widget.dataset.sitekey || SITE_KEY;
  try {
    turnstileWidgetId = window.turnstile.render(widget, {
      sitekey: siteKey,
      theme: widget.dataset.theme || "dark",
      callback: token => { turnstileToken = token; },
      "expired-callback": () => { turnstileToken = ""; },
      "error-callback": () => {
        turnstileToken = "";
        showToast("Security verification had an error. Please retry.");
      }
    });
  } catch (error) {
    console.error("Could not render Turnstile.", error);
    showToast("Security verification could not load. Refresh and try again.");
  }
}
window.addEventListener("turnstile-api-ready", renderTurnstile);
// Covers the case where the API becomes available before this module listener.
if (window.turnstile) renderTurnstile();


// Browser-based utility tools. These work without an AI provider or server.
const toolText = $("#toolText");
const textStats = $("#textStats");
function updateTextStats(){if(!toolText||!textStats)return;const v=toolText.value;textStats.textContent=`${v.length.toLocaleString()} characters · ${v.trim()?v.trim().split(/\s+/).length.toLocaleString():0} words`;}
toolText?.addEventListener("input",updateTextStats);
function copyValue(value){if(!value){showToast("Nothing to copy yet.");return;}if(navigator.clipboard&&window.isSecureContext)navigator.clipboard.writeText(value).then(()=>showToast("Copied to clipboard.")).catch(()=>fallbackCopy(value));else fallbackCopy(value);}
function fallbackCopy(value){const el=document.createElement("textarea");el.value=value;el.style.position="fixed";el.style.opacity="0";document.body.appendChild(el);el.select();try{document.execCommand("copy");showToast("Copied to clipboard.");}catch(e){showToast("Copy failed. Select and copy the text manually.");}el.remove();}
function downloadTextFile(name,value){const blob=new Blob([value],{type:"text/plain;charset=utf-8"});const url=URL.createObjectURL(blob);const a=document.createElement("a");a.href=url;a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);}
$("#saveNote")?.addEventListener("click",()=>{try{localStorage.setItem("wazirAuraNote",toolText?.value||"");showToast("Note saved in this browser.");}catch(e){showToast("Browser storage is unavailable. Download the note instead.");}});
if(toolText){try{toolText.value=localStorage.getItem("wazirAuraNote")||"";}catch(e){}updateTextStats();}
$("#downloadText")?.addEventListener("click",()=>downloadTextFile("wazir-aura-note.txt",toolText?.value||""));
$("#clearText")?.addEventListener("click",()=>{if(toolText)toolText.value="";updateTextStats();});
const caseInput=$("#caseInput"),caseOutput=$("#caseOutput");
$$("[data-case]").forEach(b=>b.addEventListener("click",()=>{const v=caseInput?.value||"";let out=v;switch(b.dataset.case){case"upper":out=v.toUpperCase();break;case"lower":out=v.toLowerCase();break;case"title":out=v.toLowerCase().replace(/\b[\p{L}\p{N}]/gu,c=>c.toUpperCase());break;case"sentence":out=v.toLowerCase().replace(/(^|[.!?]\s+)([\p{L}])/gu,(m,a,c)=>a+c.toUpperCase());break;}if(caseOutput)caseOutput.textContent=out;}));
$("#copyCase")?.addEventListener("click",()=>copyValue(caseOutput?.textContent||""));
$("#formatJson")?.addEventListener("click",()=>{const out=$("#jsonOutput");try{out.textContent=JSON.stringify(JSON.parse($("#jsonInput")?.value||""),null,2);}catch(e){out.textContent="Invalid JSON: "+e.message;}});
$("#minifyJson")?.addEventListener("click",()=>{const out=$("#jsonOutput");try{out.textContent=JSON.stringify(JSON.parse($("#jsonInput")?.value||""));}catch(e){out.textContent="Invalid JSON: "+e.message;}});
$("#baseEncode")?.addEventListener("click",()=>{try{$("#baseOutput").textContent=btoa(unescape(encodeURIComponent($("#baseInput").value)));}catch(e){$("#baseOutput").textContent="Could not encode this input.";}});
$("#baseDecode")?.addEventListener("click",()=>{try{$("#baseOutput").textContent=decodeURIComponent(escape(atob($("#baseInput").value.trim())));}catch(e){$("#baseOutput").textContent="Invalid Base64 input.";}});
const lengthRange=$("#passwordLength"),lengthValue=$("#passwordLengthValue");lengthRange?.addEventListener("input",()=>{lengthValue.textContent=lengthRange.value;});
$("#generatePassword")?.addEventListener("click",()=>{const n=Number(lengthRange?.value||20),symbols=$("#passwordSymbols")?.checked;const chars="ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz23456789"+(symbols?"!@#$%^&*()-_=+[]{};:,.?":"");const arr=new Uint32Array(n);if(crypto?.getRandomValues)crypto.getRandomValues(arr);else for(let i=0;i<n;i++)arr[i]=Math.floor(Math.random()*4294967295);$("#passwordOutput").textContent=Array.from(arr,x=>chars[x%chars.length]).join("");});
$("#copyPassword")?.addEventListener("click",()=>copyValue($("#passwordOutput")?.textContent||""));
function loadVoices(){const select=$("#voiceSelect");if(!select||!window.speechSynthesis)return;const voices=speechSynthesis.getVoices();select.innerHTML="";if(!voices.length){select.add(new Option("No system voices available",""));return;}voices.forEach((v,i)=>select.add(new Option(`${v.name} — ${v.lang}${v.default?" (default)":""}`,String(i))));}
if("speechSynthesis" in window){loadVoices();speechSynthesis.addEventListener?.("voiceschanged",loadVoices);$("#speakText")?.addEventListener("click",()=>{const text=$("#speechInput")?.value||"";if(!text.trim()){showToast("Enter text to speak first.");return;}speechSynthesis.cancel();const voice=speechSynthesis.getVoices()[Number($("#voiceSelect")?.value||0)];const chunks=text.match(/[\s\S]{1,3500}/g)||[];chunks.forEach(chunk=>{const u=new SpeechSynthesisUtterance(chunk);if(voice)u.voice=voice;speechSynthesis.speak(u);});});$("#stopSpeech")?.addEventListener("click",()=>speechSynthesis.cancel());}else{$("#voiceSelect")?.replaceChildren(new Option("Speech synthesis is not supported in this browser",""));}
const promptTemplates={image:"Create a detailed image-generation prompt",video:"Create a short-video generation prompt",website:"Act as a senior frontend developer and produce a responsive website plan/code specification",logo:"Create a professional logo/banner design brief",game:"Act as a 2D game designer and developer; produce a playable game plan and implementation specification",study:"Act as a patient tutor; explain clearly, step by step, and check understanding"};
$("#buildPrompt")?.addEventListener("click",()=>{const type=$("#promptType")?.value||"image",brief=$("#promptBrief")?.value.trim()||"[Add your idea and requirements]";$("#promptOutput").value=`${promptTemplates[type]}.\n\nPROJECT BRIEF:\n${brief}\n\nREQUIREMENTS:\n- Ask clarifying questions if critical information is missing.\n- Be specific, practical, accessible and original.\n- State assumptions and limitations.\n- For code: provide complete, clearly labelled files, explain setup, and avoid exposing secrets/API keys in frontend code.\n- Do not claim an asset, deployment, test, or integration exists unless it has actually been created and verified.`;});
$("#copyPrompt")?.addEventListener("click",()=>copyValue($("#promptOutput")?.value||""));
$("#downloadPromptCode")?.addEventListener("click",()=>downloadTextFile("wazir-aura-prompt.txt",$("#promptOutput")?.value||""));


// Contact form submission
const contactForm = $("#contactForm");
const submitButton = $("#submitButton");
const formStatus = $("#formStatus");

function setFormStatus(message, type = "") {
  if (!formStatus) return;
  formStatus.textContent = message;
  formStatus.className = `form-status ${type}`.trim();
}

contactForm?.addEventListener("submit", async event => {
  event.preventDefault();
  if (!contactForm.reportValidity()) return;

  if (!turnstileToken && !window.turnstile) {
    const fd = new FormData(contactForm);
    const subject = encodeURIComponent(String(fd.get("subject") || "Wazir Aura enquiry"));
    const body = encodeURIComponent(`Name: ${fd.get("name")}\nReply email: ${fd.get("email")}\n\n${fd.get("message")}`);
    setFormStatus("Secure form service is unavailable. Your email app will open instead.", "error");
    window.location.href = `mailto:wazirlab@proton.me?subject=${subject}&body=${body}`;
    return;
  }
  if (!turnstileToken) { setFormStatus("Please complete the security verification first.", "error"); showToast("Complete the security check before sending."); return; }

  const formData = new FormData(contactForm);
  const payload = {
    name: String(formData.get("name") || "").trim(),
    email: String(formData.get("email") || "").trim(),
    subject: String(formData.get("subject") || "").trim(),
    message: String(formData.get("message") || "").trim(),
    turnstileToken
  };

  if (submitButton) submitButton.disabled = true;
  setFormStatus("Sending your message…");

  try {
    await submitContactMessage(payload);
    setFormStatus("Thanks! Your message has been sent successfully.", "success");
    contactForm.reset();
    resetTurnstile();
    showToast("Message sent successfully.");
  } catch (error) {
    console.error("Contact form submission failed:", error);
    setFormStatus(error.message || "Message could not be sent. Please try again.", "error");
    resetTurnstile();
  } finally {
    if (submitButton) submitButton.disabled = false;
  }
});
